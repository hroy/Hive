import java.util.StringTokenizer;

import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.Text;


@Description(
	name = "FORMAT_GENRE",
	value = "_FUNC_(str) - Repalce pipeline-separated-string to a comma-separated-string with last pipeline by and",
	extended = "Example:\n" +
	"  > SELECT FORMAT_GENRE(mv_genre) FROM movies;\n" +
	"  Adventure, Animation, and Children's"
	)
	
public class FORMAT_GENRE extends UDF {

	public Text evaluate(Text s) {
		Text to_value = new Text("");
		if (s != null) {
		    try { 
				//to_value.set(s.toString().replace("|", ", "));
		    	
		    	String outStr = "";
		    	StringTokenizer strArr = new StringTokenizer(s.toString().trim(),"|");
		    	
		    	int len = strArr.countTokens();
		    	
		    	if(len>=2)
		    	{
		    		for(int i=0;i<len-1;i++)
			    	{
			    		outStr = outStr + strArr.nextToken() + ", ";
			    	}
		    		outStr = outStr + "and " + strArr.nextToken();
		    		
		    		to_value.set(outStr);
		    	}
		    	else
		    	{
		    		to_value.set(s.toString());
		    	}		
		    	
//		    	String []strArr = s.toString().trim().split("|");
//		    	int len = strArr.length;
//		    	outStr = outStr + len + ", ";
//		    	
//		    	if(len>=2)
//		    	{
//		    		for(int i=0;i<len-1;i++)
//			    	{
//			    		outStr = outStr + strArr[i] + ", ";
//			    	}
//		    		outStr = outStr + "and " + strArr[len-1];
//		    		
//		    		to_value.set(outStr);
//		    	}
//		    	else
//		    	{
//		    		to_value.set(s.toString());
//		    	}		    	
		    } catch (Exception e) { // Should never happen
				to_value = new Text(s);
		    }
		}
		return to_value;
    }
}
